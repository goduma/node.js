import { Application } from './config/Application';
export default new Application();
